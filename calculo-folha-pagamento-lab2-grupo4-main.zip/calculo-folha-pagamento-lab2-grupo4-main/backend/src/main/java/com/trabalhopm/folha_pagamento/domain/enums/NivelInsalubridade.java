package com.trabalhopm.folha_pagamento.domain.enums;

public enum NivelInsalubridade {
    NENHUM,
    BAIXO,
    MEDIO,
    ALTO
}