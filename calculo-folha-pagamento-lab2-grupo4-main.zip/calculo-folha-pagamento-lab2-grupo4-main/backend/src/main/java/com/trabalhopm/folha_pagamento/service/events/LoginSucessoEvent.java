package com.trabalhopm.folha_pagamento.service.events;

import com.trabalhopm.folha_pagamento.domain.Funcionario;

public record LoginSucessoEvent(Funcionario funcionario) {
}
