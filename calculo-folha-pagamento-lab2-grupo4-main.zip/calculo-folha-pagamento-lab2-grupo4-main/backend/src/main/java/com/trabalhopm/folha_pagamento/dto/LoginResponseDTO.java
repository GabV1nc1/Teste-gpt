package com.trabalhopm.folha_pagamento.dto;

public record LoginResponseDTO(String token) {
}
