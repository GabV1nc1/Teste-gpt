package com.trabalhopm.folha_pagamento.service.events.folha_events;

import com.trabalhopm.folha_pagamento.domain.FolhaPagamento;

public record FolhaDeletadaEvent(FolhaPagamento folhaPagamento) {
}
