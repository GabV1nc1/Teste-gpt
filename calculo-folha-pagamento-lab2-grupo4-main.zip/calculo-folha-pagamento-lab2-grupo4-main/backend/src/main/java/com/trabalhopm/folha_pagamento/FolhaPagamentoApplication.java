package com.trabalhopm.folha_pagamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FolhaPagamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FolhaPagamentoApplication.class, args);
	}

}
